import java.awt.Color;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Main extends JFrame {

	//Check list:
	//Add game screen. Done that :>
	//Add party screen. Have not done that :>
	//Make it so you can flip between both of them. Have not done that :>
	//Make it so fight panel is not visible unless in battle. 
	// Flip visibility of choice and fight panels if or if not 
	// in battle. Have not done that :>
	
	//Values that I don't intend on changing later? (At least I think this is how you set those types of values.)
	public static final String winTitle = "Modern Day: Yesteryear";
	public static final int screenX = 1200;
	public static final int screenY = 950;
	
	
	public static void main(String[] args) {
		//Note: Create panel, unintended effect gives you 2 windows.
		//This happens because I'm creating a window(Main), and then I'm
		// creating a panel(Panel) but panel extends main, so it 
		// also runs Main() method?
		
		//Other note: "Panel panel = new Panel();" is not needed to create a Panel(); :>
		
		System.out.println("We're setting up the game! Please wait just a moment!");
//		new Main();
//		System.out.println("The frame has been loaded. (Successfully?)");
		
		new Panel();
		System.out.println("The game has been loaded. (Successfully?)");
		
		
//		System.out.println("Now loading titlescreen. ");
//		display.showTitleScreen();
//		System.out.println("Titlescreen is ready. Hope you enjoy the game! :>");
	}
	
	//Finished setting up frame...?
	public Main() {
		setTitle(winTitle);
		setSize(screenX, screenY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.black);
		setResizable(false);
		isFocusable();
		requestFocus();
		setLayout(null);
		setLocationRelativeTo(null);
		
		setVisible(true);	
			
	}
	
	//Useless method to make JPanel stuff visible.
	//Didn't work, found alternative.
//	public void setContentVisible() {
//		setVisible(true);
//	}
	
}
