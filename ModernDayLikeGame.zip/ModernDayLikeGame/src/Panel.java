import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

@SuppressWarnings("serial")
public class Panel extends Main {

	//Note: figured out how to make it display the rectangle without
	// furiously extending JPanel. extend the class that extends what 
	// you would need to extend. :>
	
//	Main window;
	JPanel titlePanel, titleButtonPanel, gameFramePanel, gameImagePanel, backTransparencyPanel, backgroundImagePanel, gameChoicePanel, 
		   statusPanel, gameTextPanel, gameFightPanel, gameMiscPanel, partyMember1, partyMember2, partyMember3, partyMember4,
		   partyStyle, gameBackPanel;
	JLabel titleLabelMain, titleLabel, gameFrameLabel, gameImageLabel, backgroundImageLabel,
			partyImageLabel1, partyImageLabel2, partyImageLabel3, partyImageLabel4;
	JButton titleButton, choice1, choice2, choice3, choice4, gameFight, gameSpecial, gameRun, gameParty, gameBack;
	JTextArea gameTextArea, statusTextArea, partyText1, partyText2, partyText3, partyText4;
	ImageIcon frameImage, gameImage, backgroundImage, partyImage1, partyImage2, partyImage3, partyImage4;
	
	Story story = new Story();
	
// Unimplemented feature: Music. Wasn't necessary so was not included. 
	
//Custom stuff like fonts and colors!
//Note: Transparency does work! :>
// It gets what's behind the JPanel. If I were to change
// the frame background to RED, the button's background would
// also be RED! Instead of the expected result (Black or JPanel(Color))
// One more thing, transparency is 255 (No transparency)
// to 0 (100% transparent)
	Font testFont = new Font("NSimSun", 1, 70);
	Font testFont2 = new Font("NSimSun", 5, 50);
	Font storyFont = new Font("NSimSun", 5, 20);
	Font choiceFont = new Font("NSimSun", 5, 14);
	Color gameTransparent = new Color(255, 255, 255, 0);
	Color backTransparent = new Color(0, 0, 0, 100);
	Color styleTransparent = new Color(255, 255, 255, 100);
	Color gameTextColor = new Color(255, 255, 255, 200);
	
	//Handlers!
	GameHandler gHandler = new GameHandler();
	
	//Display stuff.
	String imageFrame;
	String gamePosImage;
	String backGround;
	String choiceStr1, choiceStr2, choiceStr3, choiceStr4;
	String partyMem1, partyMem2, partyMem3, partyMem4;
	String nextPos1, nextPos2, nextPos3, nextPos4;
	String statusArea = "Current area status:\n", noStatuses = "Nothing right now!";
	
	public Panel() {
		
		//Sets the strings so they aren't null on start.
		imageFrame = ".\\res\\images\\frame.png";
		gamePosImage = ".\\res\\images\\titlePos.png";
		backGround = ".\\res\\images\\background.png";
		partyMem1 = ".\\res\\images\\placeChar.png";
		
		nextPos1 = "house";
		nextPos2 = "Nothing!";
		nextPos3 = "Nothing!";
		nextPos4 = "Nothing!";
		
		backgroundImage = new ImageIcon(backGround);
		frameImage = new ImageIcon(imageFrame);
		gameImage = new ImageIcon(gamePosImage);
		
		//Creates the titlescreen label
		titlePanel = new JPanel();
		titlePanel.setBounds(100, 50, screenX / 2 + 400, 250); // Unnecessary maths X>
		titlePanel.setBackground(gameTransparent);
		titlePanel.setLayout(new GridLayout(2, 1));
		
		titleLabelMain = new JLabel("Modern Day:", SwingConstants.CENTER);
		titleLabelMain.setForeground(Color.white);
		titleLabelMain.setFont(testFont);
		
		titleLabel = new JLabel("Yesteryear", SwingConstants.CENTER);
		titleLabel.setForeground(Color.white);
		titleLabel.setFont(testFont2);
		
		titlePanel.add(titleLabelMain);
		titlePanel.add(titleLabel);
		
		add(titlePanel);
		
		//Creates the titlescreen button
		titleButtonPanel = new JPanel();
		titleButtonPanel.setBounds(screenX / 2 - 100, screenY / 2 + 350, 200, 100);
		titleButtonPanel.setBackground(gameTransparent);
		
		titleButton = new JButton("Test");
		titleButton.setBackground(Color.black);
		titleButton.setForeground(Color.white);
		titleButton.setFont(testFont2);
		titleButton.addActionListener(gHandler);	
		titleButton.setActionCommand("start");
		titleButton.setFocusPainted(false);
		
		titleButtonPanel.add(titleButton);
		
		add(titleButtonPanel);
		
		//Adding the frame that images are put inside.
		//Note: Consider changing frame for certain strange situations.
		gameFramePanel = new JPanel();
		gameFramePanel.setBounds(screenX / 4, screenY / 2 - 200, 594, 506 + 5);
		gameFramePanel.setBackground(gameTransparent);
		
		gameFrameLabel = new JLabel();
		
		gameFrameLabel.setIcon(frameImage);
		gameFramePanel.add(gameFrameLabel);
		
//		System.out.println("Image 1 loaded!");
		add(gameFramePanel);

		//Adding the image in the frame.
		
		gameImagePanel = new JPanel();
		gameImagePanel.setBounds(screenX / 4 + 5, screenY / 2 - 196, 585, 601);
		gameImagePanel.setBackground(Color.black);
				
		gameImageLabel = new JLabel();
		
		gameImageLabel.setIcon(gameImage);
		gameImagePanel.add(gameImageLabel);
		
		
//		System.out.println("Image 2 loaded!");
		add(gameImagePanel);
		
//		Implementing the game.
		
		//Adding the party's current status for that area.
		// As in like when you get hit it will write a message 
		// letting you know how much you took.
		//It can hold many different lines. 
		// Too lazy to count :P
		
		statusPanel = new JPanel();
		statusPanel.setBounds(1000, 270, 150, 510);
		statusPanel.setBackground(Color.black);
		statusPanel.setLayout(new GridLayout(1, 1));
		
		statusTextArea = new JTextArea(statusArea + noStatuses);
		statusTextArea.setBackground(Color.black);
		statusTextArea.setForeground(Color.white);
		statusTextArea.setEditable(false);
		statusTextArea.setLineWrap(true);
		statusTextArea.setHighlighter(null);
		
		statusPanel.add(statusTextArea);
		add(statusPanel);
		
		//Adding the game text area.
		//Note: Text area can only hold more than 4 now lines without going of screen.
		
		gameTextPanel = new JPanel();
		gameTextPanel.setBounds(screenX / 4, 50, screenX / 2 - 7, 225);
		gameTextPanel.setBackground(Color.black);
		
		gameTextArea = new JTextArea();
		gameTextArea.setText("This is a placeholder!");
		gameTextArea.setBounds(screenX / 4, 50, screenX / 2 - 7, 200);
		gameTextArea.setBackground(Color.black);
		gameTextArea.setForeground(Color.white);
		gameTextArea.setFont(storyFont);
		gameTextArea.setEditable(false);
		gameTextArea.setLineWrap(true);
		gameTextArea.setHighlighter(null);
		
		gameTextPanel.add(gameTextArea);
		add(gameTextPanel);
		
		//Adding the choices
		//Note: They can hold 13 characters each.
		// Unless you make certain buttons invisible.
		
		gameChoicePanel = new JPanel();
		gameChoicePanel.setBounds(screenX / 2 - 304, screenY / 2 + 320, 600, 100);
		gameChoicePanel.setBackground(gameTransparent);
		gameChoicePanel.setLayout(new GridLayout(1, 4));
		
		choice1 = new JButton("Placeholder 1");
		choice1.setBackground(Color.black);
		choice1.setForeground(Color.white);
		choice1.setFont(choiceFont);
		choice1.addActionListener(gHandler);	
		choice1.setActionCommand("c1");
		choice1.setFocusPainted(false);
		choice2 = new JButton("Placeholder 2");
		choice2.setBackground(Color.black);
		choice2.setForeground(Color.white);
		choice2.setFont(choiceFont);
		choice2.addActionListener(gHandler);	
		choice2.setActionCommand("c2");
		choice2.setFocusPainted(false);
		choice3 = new JButton("Placeholder 3");
		choice3.setBackground(Color.black);
		choice3.setForeground(Color.white);
		choice3.setFont(choiceFont);
		choice3.addActionListener(gHandler);	
		choice3.setActionCommand("c3");
		choice3.setFocusPainted(false);
		choice4 = new JButton("Placeholder 4");
		choice4.setBackground(Color.black);
		choice4.setForeground(Color.white);
		choice4.setFont(choiceFont);
		choice4.addActionListener(gHandler);	
		choice4.setActionCommand("c4");
		choice4.setFocusPainted(false);
		
		gameChoicePanel.add(choice1);
		gameChoicePanel.add(choice2);
		gameChoicePanel.add(choice3);
		gameChoicePanel.add(choice4);
		add(gameChoicePanel);
		
		//Adding the battle buttons.
		
		gameFightPanel = new JPanel();
		gameFightPanel.setBounds(screenX / 2 - 510, screenY / 2 - 190, 130, 400);
		gameFightPanel.setBackground(gameTransparent);
		gameFightPanel.setLayout(new GridLayout(3, 1));
		
		gameFight = new JButton("Fight");
		gameFight.setBackground(Color.black);
		gameFight.setForeground(Color.white);
		gameFight.setFont(choiceFont);
		gameFight.addActionListener(gHandler);
		gameFight.setActionCommand("fight");
		gameFight.setFocusPainted(false);
		gameSpecial = new JButton("Special");
		gameSpecial.setBackground(Color.black);
		gameSpecial.setForeground(Color.white);
		gameSpecial.setFont(choiceFont);
		gameSpecial.addActionListener(gHandler);
		gameSpecial.setActionCommand("special");
		gameSpecial.setFocusPainted(false);
		gameRun = new JButton("Run");
		gameRun.setBackground(Color.black);
		gameRun.setForeground(Color.white);
		gameRun.setFont(choiceFont);
		gameRun.addActionListener(gHandler);
		gameRun.setActionCommand("run");
		gameRun.setFocusPainted(false);
		
		gameFightPanel.add(gameFight);
		gameFightPanel.add(gameSpecial);
		gameFightPanel.add(gameRun);
		add(gameFightPanel);
		
		//Adding the party and music button. (Music was not added :< )
		
		gameMiscPanel = new JPanel();
		gameMiscPanel.setBounds(screenX / 2 - 510, screenY / 2 + 320, 130, 100);
		gameMiscPanel.setBackground(Color.blue);
		gameMiscPanel.setLayout(new GridLayout(1, 1));
		
		gameParty = new JButton("Party");
		gameParty.setBackground(Color.black);
		gameParty.setForeground(Color.white);
		gameParty.setFont(choiceFont);
		gameParty.addActionListener(gHandler);
		gameParty.setActionCommand("party");
		gameParty.setFocusPainted(false);
		
		gameMiscPanel.add(gameParty);
		add(gameMiscPanel);
		
		//Adding the stuff for the party screen
		//Note: Make it so party members aren't displayed until obtained 
		// same thing with the stats. There are only 4 in the game 
		// and you will most likely find them during the story. The 
		// fourth one is secret :>
		
		partyMember1 = new JPanel();
		partyMember1.setBounds(300, 200, 300, 300);
		partyMember1.setBackground(backTransparent);
		partyMember1.setLayout(new GridLayout(1, 2));
		
		partyMember2 = new JPanel();
		partyMember2.setBounds(partyMember1.getX() * 2 + 10, 200, 300, 300);
		partyMember2.setBackground(backTransparent);
		partyMember2.setLayout(new GridLayout(1, 2));
		
		partyMember3 = new JPanel();
		partyMember3.setBounds(partyMember1.getX(), partyMember1.getY() * 2 + 110, 300, 300);
		partyMember3.setBackground(backTransparent);
		partyMember3.setLayout(new GridLayout(1, 2));
		
		partyMember4 = new JPanel();
		partyMember4.setBounds(partyMember1.getX() * 2 + 10, partyMember1.getY() * 2 + 110, 300, 300);
		partyMember4.setBackground(backTransparent);
		partyMember4.setLayout(new GridLayout(1, 2));
		
		partyStyle = new JPanel();
		partyStyle.setBounds(partyMember1.getX(), partyMember1.getY(), partyMember1.getX() * 2 + 10, partyMember4.getY() + 100);
		partyStyle.setBackground(styleTransparent);
		
		partyImageLabel1 = new JLabel();
		partyImage1 = new ImageIcon(partyMem1);
		
		partyImageLabel1.setIcon(partyImage1);
		partyMember1.add(partyImageLabel1);
		
		partyText1 = new JTextArea("Placeholder");
		partyText1.setBackground(gameTransparent);
		partyText1.setForeground(gameTextColor);
		partyText1.setFont(choiceFont);
		partyText1.setEditable(false);
		partyText1.setLineWrap(true);
		partyText1.setHighlighter(null);
		partyMember1.add(partyText1);
		
		//The other party member panels will get properly made later in the code.
		
		partyText2 = new JTextArea("There is no party member for this slot!");
		partyText2.setBackground(gameTransparent);
		partyText2.setForeground(gameTextColor);
		partyText2.setFont(choiceFont);
		partyText2.setEditable(false);
		partyText2.setLineWrap(true);
		partyText2.setHighlighter(null);
		partyMember2.add(partyText2);
		
		partyText3 = new JTextArea("There is no party member for this slot!");
		partyText3.setBackground(gameTransparent);
		partyText3.setForeground(gameTextColor);
		partyText3.setFont(choiceFont);
		partyText3.setEditable(false);
		partyText3.setLineWrap(true);
		partyText3.setHighlighter(null);
		partyMember3.add(partyText3);
		
		partyText4 = new JTextArea("There is no party member for this slot!");
		partyText4.setBackground(gameTransparent);
		partyText4.setForeground(gameTextColor);
		partyText4.setFont(choiceFont);
		partyText4.setEditable(false);
		partyText4.setLineWrap(true);
		partyText4.setHighlighter(null);
		partyMember4.add(partyText4);
		
		add(partyMember4);
		add(partyMember3);
		add(partyMember2);
		add(partyMember1);
		add(partyStyle);
		
		//Adding the back button in partyscreen
		
		gameBackPanel = new JPanel();
		gameBackPanel.setBounds(100, 100, 150, 100);
		gameBackPanel.setBackground(Color.blue);
		gameBackPanel.setLayout(new GridLayout(1, 1));
		
		gameBack = new JButton("Back to game");
		gameBack.setBackground(Color.black);
		gameBack.setForeground(Color.white);
		gameBack.setFont(choiceFont);
		gameBack.addActionListener(gHandler);
		gameBack.setActionCommand("back");
		gameBack.setFocusPainted(false);
		
		gameBackPanel.add(gameBack);
		add(gameBackPanel);
		
//		System.out.println("party1 x: " + partyMember1.getX());
//		System.out.println("party4 y: " + partyMember4.getY());
		
		//Note: For background to work put at bottom of initializing code.
		// I think this is because it loads from top to bottom, so 
		// it loads panels on different layers from top(highest priority) to bottom(lowest priority)
		
		//Adding the background overlay color.
		
		backTransparencyPanel = new JPanel();
		backTransparencyPanel.setBounds(0, 0, screenX, screenY);
		backTransparencyPanel.setBackground(backTransparent);
		
		add(backTransparencyPanel);
		
		//Adding the background.
		
		backgroundImagePanel = new JPanel();
		backgroundImagePanel.setBounds(0 - 5, 0 - 10, screenX, screenY);
		backgroundImagePanel.setBackground(Color.blue);
						
		backgroundImageLabel = new JLabel();
						
		backgroundImageLabel.setIcon(backgroundImage);
		backgroundImagePanel.add(backgroundImageLabel);
						
		add(backgroundImagePanel);
		
		showTitleScreen();
		
	}
	
	//Remember to remove use of method. Seems redundant.
	public void showTitleScreen() {
		//Sets all game panels invis until player starts the game.
//		System.out.println("Images loaded?");
		
		titlePanel.setVisible(true);
		titleButtonPanel.setVisible(true);
		gameFramePanel.setVisible(true);
		gameImagePanel.setBackground(gameTransparent);
		gameImagePanel.setVisible(true);
	
		//Setting visibility of game panels
		
		statusPanel.setVisible(false); //This needs to be here for it to work correctly?
		gameTextPanel.setVisible(false);
		gameChoicePanel.setVisible(false);
		gameFightPanel.setVisible(false);
		gameMiscPanel.setVisible(false);
		
		//Setting visibility of party panels
		
		partyMember1.setVisible(false);
		partyMember2.setVisible(false);
		partyMember3.setVisible(false);
		partyMember4.setVisible(false);
		partyStyle.setVisible(false);
		gameBackPanel.setVisible(false);
		
//		
		//Test code to see if I can change visibility on the fly.
//		titlePanel.setVisible(false);
//		titleButtonPanel.setVisible(false);
//		testGamePanel.setVisible(true);
		
//		System.out.println("Trying to get content...");
//		setVisible(true);
//		System.out.println("Showing content");
		//It works. :>
		
	}
		
	public void showGameScreen() {
		//Sets all titlescreen panels invis when player starts game.
		
		titlePanel.setVisible(false);
		titleButtonPanel.setVisible(false);
		gameFramePanel.setVisible(true);
		gameImagePanel.setBackground(gameTransparent);
		gameImagePanel.setVisible(true);
		
		//Setting visibility of game panels. Except fight panel
		// because the player has not entered battle yet
		
		statusPanel.setVisible(true); //This needs to be here for it to work correctly?
		gameTextPanel.setVisible(true);
		gameChoicePanel.setVisible(true);
		gameFightPanel.setVisible(false);
		gameMiscPanel.setVisible(true);
		
		//Setting visibility of party panels
		
		partyMember1.setVisible(false);
		partyMember2.setVisible(false);
		partyMember3.setVisible(false);
		partyMember4.setVisible(false);
		partyStyle.setVisible(false);
		gameBackPanel.setVisible(false);
		
//		setVisible(true);
		
	}
	
	public void showPartyScreen() {	
		//Sets all panels to invis so the player can 
		// focus on their party's stats
		
		titlePanel.setVisible(false);
		titleButtonPanel.setVisible(false);
		gameFramePanel.setVisible(false);
		gameImagePanel.setBackground(gameTransparent);
		gameImagePanel.setVisible(false);
		
		//Setting visibility of game panels
		
		statusPanel.setVisible(false); //This needs to be here for it to work correctly?
		gameTextPanel.setVisible(false);
		gameChoicePanel.setVisible(false);
		gameFightPanel.setVisible(false);
		gameMiscPanel.setVisible(false);
		
		//Setting visibility of party panels
		
		partyMember1.setVisible(true);
		partyMember2.setVisible(true);
		partyMember3.setVisible(true);
		partyMember4.setVisible(true);
		partyStyle.setVisible(true);
		gameBackPanel.setVisible(true);
	}
	
	public void showFightScreen() {
		//Sets most gamescreen panels invisible when player enters battle.
		
		titlePanel.setVisible(false);
		titleButtonPanel.setVisible(false);
		gameFramePanel.setVisible(true);
		gameImagePanel.setBackground(gameTransparent);
		gameImagePanel.setVisible(true);
				
		//Setting visibility of game panels
				
		statusPanel.setVisible(true); //This needs to be here for it to work correctly?
		gameTextPanel.setVisible(true);
		gameChoicePanel.setVisible(false);
		gameFightPanel.setVisible(true);
		gameMiscPanel.setVisible(true);
				
		//Setting visibility of party panels
				
		partyMember1.setVisible(false);
		partyMember2.setVisible(false);
		partyMember3.setVisible(false);
		partyMember4.setVisible(false);
		partyStyle.setVisible(false);
		gameBackPanel.setVisible(false);
				
	}
	
	public class GameHandler implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			//Works!!!! :D!!!!
			
			String startGame = e.getActionCommand();
			
			System.out.println(startGame);
			
			switch(startGame) {
			case "start": showGameScreen(); story.wakeUp(); break;
			case "party": showPartyScreen(); break;
			case "back": showGameScreen(); break;
			case "c1": story.selectPos(nextPos1); break;
			case "c2": story.selectPos(nextPos2); break;
			case "c3": story.selectPos(nextPos3); break;
			case "c4": story.selectPos(nextPos4); break;
			}
			
		}

	}
	
	
	
	//Big ol' mess :>
	public class Story {
		
		
		//Story variables
		//House section
		boolean seenHomeComputer = false;
		boolean seenSnowGoose = false;
		boolean rudeComment = false;
		boolean seenHomeRug = false;
		//House section end
		
		int meanPnts = 0;
		int integrityPnts = 0;
		
		//Path changers
		boolean youtubeQuest = false;
		
	
		
		public void selectPos(String nextPos) {
			//Switches the game based on the pos string
			System.out.println(seenHomeComputer + " " + rudeComment + " " + meanPnts + " " + integrityPnts + " " + youtubeQuest + " " + seenSnowGoose + " " +
			 seenHomeRug );
			
			switch(nextPos) {
			case "start": beginGame(); showTitleScreen(); break;
			case "house": wakeUp(); break;
			case "homeComputer": homeComputer(); break;
			case "angryComment": angryComment(); break;
			case "copyRight": copyRight(); break;
			case "youtubeQuest": youtubeQuest(); break;
			case "snowGoose": snowGoose(); break;
			case "homeRug": homeRug(); break;
			case "removeRug": removeRug(); break;
			case "badEnd1": badEnding1(); break;
			case "leaveHouse": leaveHouse(); break;
			}
		}
	
		public void beginGame() {
			//Sets the game to what it would be if you started. 
			// Happens when you get an ending.
			seenHomeComputer = false;
			seenSnowGoose = false;
			rudeComment = false;
			seenHomeRug = false;
			
			
			meanPnts = 0;
			integrityPnts = 0;
			
			
			youtubeQuest = false;
		}
		
	//This is everything in the house scene
		public void wakeUp() {
			statusTextArea.setText(statusArea + noStatuses);
			if(!rudeComment) {gameTextArea.setText("You are awake... Usually you would rather sleep.\nBut today feels like no other day you've waken up on. You\nwonder why."
					+ "\n\nYou are now in your ROOM.\nIt doesn't look like much but this place has really\ngrown onto you.\n\nYou can do so much here, what will you do?"); }
			if(youtubeQuest) { gameTextArea.setText("You know what you are going to do today.\nThough it doesn't look like it. You are quite excited to\ngo on this quest!"); }
			else { gameTextArea.setText("What a great start to your day! You spent time on the\ncomputer schooling people.\n\nWhat will you do next? "); }
			gamePosImage = ".\\res\\images\\getUp.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			
			if(seenHomeComputer && !seenSnowGoose && !seenHomeRug) { choice1.setText("Look at trophy"); }
			else if(seenSnowGoose && !seenHomeComputer && !seenHomeRug) { choice1.setText("Get on Computer"); }
			else if(seenHomeRug && !seenHomeComputer && !seenSnowGoose) { choice1.setText("Get on Computer"); }
			else if(seenHomeRug && seenHomeComputer && !seenSnowGoose) { choice1.setText("Look at trophy"); }
			else if(seenHomeRug && seenSnowGoose && !seenHomeComputer) { choice1.setText("Get on Computer"); }
			else if(seenSnowGoose && seenHomeComputer && !seenHomeRug) { choice1.setText("Inspect rug"); }
			else if(seenSnowGoose && seenHomeComputer && seenHomeRug) { choice1.setText("Leave house"); }
			else { choice1.setText("Get on computer"); }
			
			if(seenHomeComputer && !seenSnowGoose && !seenHomeRug) { choice2.setText("Inspect rug"); }
			else if(seenSnowGoose && !seenHomeComputer && !seenHomeRug) { choice2.setText("Inspect rug"); }
			else if(seenHomeRug && !seenHomeComputer && !seenSnowGoose) { choice2.setText("Look at trophy"); }
			else if(seenHomeRug && seenHomeComputer && !seenSnowGoose) { choice2.setText("Leave house"); }
			else if(seenHomeRug && seenSnowGoose && !seenHomeComputer) { choice2.setText("Leave house"); }
			else if(seenSnowGoose && seenHomeComputer && !seenHomeRug) { choice2.setText("Leave house"); }
			else if(seenSnowGoose && seenHomeComputer && seenHomeRug) { choice2.setText(null); }
			else { choice2.setText("Look at trophy"); }
			
			if(seenHomeComputer && !seenSnowGoose && !seenHomeRug) { choice3.setText("Leave house"); }
			else if(seenSnowGoose && !seenHomeComputer && !seenHomeRug) { choice3.setText("Leave house"); }
			else if(seenHomeRug && !seenHomeComputer && !seenSnowGoose) { choice3.setText("Leave house"); }
			else if(seenHomeRug && seenHomeComputer && !seenSnowGoose) { choice3.setText(null); }
			else if(seenHomeRug && seenSnowGoose && !seenHomeComputer) { choice3.setText(null); }
			else if(seenSnowGoose && seenHomeComputer && !seenHomeRug) { choice3.setText(null); }
			else if(seenSnowGoose && seenHomeComputer && seenHomeRug) { choice3.setText(null); }
			else { choice3.setText("Inspect rug"); }
			
			if(!seenHomeComputer && !seenSnowGoose && !seenHomeRug) { choice4.setText("Leave house"); }
			else { choice4.setText(null); }

			if(seenHomeComputer && !seenSnowGoose && !seenHomeRug) { nextPos1 = "snowGoose"; }
			else if(seenSnowGoose && !seenHomeComputer && !seenHomeRug) { nextPos1 = "homeComputer"; }
			else if(seenHomeRug && seenHomeComputer && !seenSnowGoose) { nextPos1 = "snowGoose"; }
			else if(seenHomeRug && seenSnowGoose && !seenHomeComputer) { nextPos1 = "homeComputer"; }
			else if(seenSnowGoose && seenHomeComputer && !seenHomeRug) { nextPos1 = "homeRug"; }
			else if(seenSnowGoose && seenHomeComputer && seenHomeRug) { nextPos1 = "leaveHouse"; }
			else { nextPos1 = "homeComputer";}
			
			if(seenHomeComputer && !seenSnowGoose && !seenHomeRug) { nextPos2 = "homeRug"; }
			else if(seenSnowGoose && !seenHomeComputer && !seenHomeRug) { nextPos2 = "homeRug";}
			else if(seenHomeRug && seenHomeComputer && !seenSnowGoose) { nextPos2 = "leaveHouse"; }
			else if(seenHomeRug && seenSnowGoose && !seenHomeComputer) { nextPos2 = "leaveHouse"; }
			else if(seenSnowGoose && seenHomeComputer  && !seenHomeRug) { nextPos2 = "leaveHouse"; }
			else if(seenSnowGoose && seenHomeComputer && seenHomeRug) { nextPos2 = "Nothing!"; }
			else { nextPos2 = "snowGoose"; }
			
			if(seenHomeComputer && !seenSnowGoose && !seenHomeRug) { nextPos3 = "leaveHouse"; }
			else if(seenSnowGoose && !seenHomeComputer && !seenHomeRug) { nextPos3 = "leaveHouse"; }
			else if(seenHomeRug && !seenHomeComputer && !seenSnowGoose) { nextPos3 = "leaveHouse"; }
			else if(seenHomeRug && seenHomeComputer && !seenSnowGoose) { nextPos3 = "Nothing!"; }
			else if(seenHomeRug && seenSnowGoose && !seenHomeComputer) { nextPos3 = "Nothing!"; }
			else if(seenSnowGoose && seenHomeComputer && !seenHomeRug) { nextPos3 = "Nothing!"; }
			else if(seenSnowGoose && seenHomeComputer && seenHomeRug) { nextPos3 = "Nothing!"; }
			else { nextPos3 = "homeRug"; }
			
			if(!seenHomeComputer && !seenSnowGoose && !seenHomeRug) { nextPos4 = "leaveHouse";}
			else { nextPos4 = "Nothing!"; }
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		
		//Everything on the computer
		public void homeComputer() {
			seenHomeComputer = true;
			gameTextArea.setText("You get on your computer. Immediatly you are greeted with\nthe worst video on the net. You would rather not speak of\nit's name."
					+ "\n\nYou are so angry you contemplate leaving an angry comment! Or even sending a copyright takedown claim to youtube\nthemself.");
			gamePosImage = ".\\res\\images\\homeComputer.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			choice1.setText("Angry comment");
			choice2.setText("Copyright strike");
			choice3.setText("Go to youtube");
			choice4.setText("Nevermind");

			nextPos1 = "angryComment";
			nextPos2 = "copyRight";
			nextPos3 = "youtubeQuest";
			nextPos4 = "house";
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		
		public void angryComment() {
			rudeComment = true;
			meanPnts++;
			statusTextArea.setText(statusArea + "Gained +1 mean point!");
			gameTextArea.setText("You have decided that you will leave an angry comment on\nthis person's video. "
					+ "You end up getting into a flame war\nwith the comment section.\n\nWas that a waste of time? You wonder. Nahhhh it totally\nwas worth it.");
			gamePosImage = ".\\res\\images\\angryComment.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			choice1.setText("Continue");
			choice2.setText(null);
			choice3.setText(null);
			choice4.setText(null);

			nextPos1 = "house";
			nextPos2 = "Nothing!";
			nextPos3 = "Nothing";
			nextPos4 = "Nothing";
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		
		public void copyRight() {
			integrityPnts++;
			statusTextArea.setText(statusArea + "Gained +1 integrity point!");
			gameTextArea.setText("You think you will give this video a hard smash with the\ncopyright hammer."
					+ " No way will you let this video hurt your reputation!\n\nSuccess it got taken down!");
			gamePosImage = ".\\res\\images\\copyRight.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			choice1.setText("Continue");
			choice2.setText(null);
			choice3.setText(null);
			choice4.setText(null);

			nextPos1 = "house";
			nextPos2 = "Nothing!";
			nextPos3 = "Nothing";
			nextPos4 = "Nothing";
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		
		public void youtubeQuest() {
			youtubeQuest = true;
			gameTextArea.setText("With doubt in your mind. You think that... "
					+ "your copyright\nstrike has a low chance of taking this horror down.\n\nMaybe going to Youtube HQ would ensure your life's\nintegrity");
			gamePosImage = ".\\res\\images\\youtubeQuest.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			choice1.setText("Continue");
			choice2.setText(null);
			choice3.setText(null);
			choice4.setText(null);

			nextPos1 = "house";
			nextPos2 = "Nothing!";
			nextPos3 = "Nothing";
			nextPos4 = "Nothing";
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		//Computer options completed.
		
		public void snowGoose() {
			seenSnowGoose = true;
			gameTextArea.setText("This is your favorite bird, the Snowgoose. So majestic..."
					+ "\n\nYou tend to look at this thing a lot when you are bored.");
			gamePosImage = ".\\res\\images\\snowGoose.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			choice1.setText("Continue");
			choice2.setText(null);
			choice3.setText(null);
			choice4.setText(null);

			nextPos1 = "house";
			nextPos2 = "Nothing!";
			nextPos3 = "Nothing";
			nextPos4 = "Nothing";
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		
		public void homeRug() {
			seenHomeRug = true;
			gameTextArea.setText("This is your rug. It's quite bland you'll admit. But it\ncompliments your blue room. Without it, nothing would\nstick out.");
			gamePosImage = ".\\res\\images\\homeRug.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			choice1.setText("Remove rug");
			choice2.setText("Continue");
			choice3.setText(null);
			choice4.setText(null);

			nextPos1 = "removeRug";
			nextPos2 = "house";
			nextPos3 = "Nothing!";
			nextPos4 = "Nothing!";
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		
		public void removeRug() {
			gameTextArea.setText("Really? Okay, you remove the rug and... There's a trap\ndoor? How could something like this be in an apartment.\nDoes it lead to the apartment below?\n\nThe mystery intrigues you.");
			gamePosImage = ".\\res\\images\\removeRug.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			choice1.setText("Enter");
			choice2.setText("Go back");
			choice3.setText(null);
			choice4.setText(null);

			nextPos1 = "badEnd1";
			nextPos2 = "house";
			nextPos3 = "Nothing!";
			nextPos4 = "Nothing!";
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		
		public void badEnding1() {
			gameTextArea.setText("You enter the trap door. It doesn't have a ladder so you\njust kind of fall. You are now stuck down here. There is\nnothing you can do in here.\n\n		"
					+ "	[GAME OVER]");
			gamePosImage = ".\\res\\images\\badEnd1.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			choice1.setText("End");
			choice2.setText(null);
			choice3.setText(null);
			choice4.setText(null);

			nextPos1 = "start";
			nextPos2 = "Nothing!";
			nextPos3 = "Nothing!";
			nextPos4 = "Nothing!";
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		
		//House section is complete
		public void leaveHouse() {
			gameTextArea.setText("You are now outside. You can consider your options...\n\n		   [END OF PROTOTYPE]");
			gamePosImage = ".\\res\\images\\leaveHouse.png";
			gameImage = new ImageIcon(gamePosImage);
			gameImageLabel.setIcon(gameImage);
			gameFramePanel.setVisible(false);
			gameFramePanel.setVisible(true);
			gameImagePanel.setVisible(true);
			
			choice1.setText("End");
			choice2.setText(null);
			choice3.setText(null);
			choice4.setText(null);

			nextPos1 = "start";
			nextPos2 = "Nothing!";
			nextPos3 = "Nothing!";
			nextPos4 = "Nothing!";
				
			System.out.print(nextPos1 + " ");
			System.out.print(nextPos2 + " ");
			System.out.print(nextPos3 + " ");
			System.out.print(nextPos4 + " ");
		}
		
		
	}
}
