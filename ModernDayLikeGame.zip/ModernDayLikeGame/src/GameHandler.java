//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//public class GameHandler implements ActionListener {
//
//	Panel startChoice;
//	
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		
//		String startGame = e.getActionCommand();
//		
//		System.out.println(startGame);
//		
//		switch(startGame) {
//		case "start": startChoice.showGameScreen();  break;
//		}
//		
//	}
//
//}
